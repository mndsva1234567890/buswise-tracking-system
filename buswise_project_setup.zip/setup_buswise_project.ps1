﻿$ErrorActionPreference = "Stop"

$ProjectRoot = "D:\mokshith\buswise-fare-intelligence-analytics"
$ScriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Path
$DatasetSource = Join-Path $ScriptFolder "buswise_synthetic_dataset_500.csv"

$Folders = @(
    "$ProjectRoot\data\raw",
    "$ProjectRoot\data\processed",
    "$ProjectRoot\python",
    "$ProjectRoot\sql",
    "$ProjectRoot\snowflake",
    "$ProjectRoot\excel",
    "$ProjectRoot\powerbi",
    "$ProjectRoot\tableau",
    "$ProjectRoot\images",
    "$ProjectRoot\report"
)

foreach ($Folder in $Folders) {
    New-Item -ItemType Directory -Path $Folder -Force | Out-Null
}

$Readme = @"
# BusWise Fare Intelligence Analytics

An end-to-end data analytics project for analysing bus fares across RedBus and AbhiBus.

## Tools
- Excel
- SQL
- Snowflake
- Python and Pandas
- Power BI
- Tableau

## Dataset
The raw dataset is stored at:
data/raw/bus_fare_raw.csv
"@
Set-Content -Path "$ProjectRoot\README.md" -Value $Readme -Encoding UTF8

$CreateTables = @"
CREATE TABLE bus_fares (
    search_id VARCHAR(30) PRIMARY KEY,
    source_city VARCHAR(100),
    destination_city VARCHAR(100),
    travel_date DATE,
    search_date DATE,
    platform VARCHAR(30),
    bus_operator VARCHAR(150),
    bus_type VARCHAR(100),
    departure_time TIME,
    arrival_time TIME,
    duration_hours DECIMAL(5,2),
    fare DECIMAL(10,2),
    seats_available INT,
    rating DECIMAL(2,1),
    booking_url VARCHAR(1000)
);
"@
Set-Content -Path "$ProjectRoot\sql\create_tables.sql" -Value $CreateTables -Encoding UTF8

$AnalysisQueries = @"
-- Average fare by platform
SELECT platform, ROUND(AVG(fare), 2) AS average_fare
FROM bus_fares
GROUP BY platform
ORDER BY average_fare;

-- Cheapest routes
SELECT source_city, destination_city, MIN(fare) AS minimum_fare
FROM bus_fares
GROUP BY source_city, destination_city
ORDER BY minimum_fare;
"@
Set-Content -Path "$ProjectRoot\sql\bus_fare_analysis_queries.sql" -Value $AnalysisQueries -Encoding UTF8

$InterviewQueries = @"
-- Find the second-highest fare
SELECT MAX(fare) AS second_highest_fare
FROM bus_fares
WHERE fare < (SELECT MAX(fare) FROM bus_fares);

-- Rank operators by average fare
SELECT
    bus_operator,
    AVG(fare) AS average_fare,
    DENSE_RANK() OVER (ORDER BY AVG(fare)) AS fare_rank
FROM bus_fares
GROUP BY bus_operator;
"@
Set-Content -Path "$ProjectRoot\sql\interview_queries.sql" -Value $InterviewQueries -Encoding UTF8

$SnowflakeSetup = @"
CREATE OR REPLACE DATABASE BUSWISE_DB;
CREATE OR REPLACE SCHEMA BUSWISE_DB.ANALYTICS;
USE DATABASE BUSWISE_DB;
USE SCHEMA ANALYTICS;
"@
Set-Content -Path "$ProjectRoot\snowflake\snowflake_setup.sql" -Value $SnowflakeSetup -Encoding UTF8

$StageFormat = @"
CREATE OR REPLACE FILE FORMAT BUSWISE_CSV_FORMAT
TYPE = CSV
FIELD_OPTIONALLY_ENCLOSED_BY = '"'
SKIP_HEADER = 1
NULL_IF = ('', 'NULL');

CREATE OR REPLACE STAGE BUSWISE_STAGE
FILE_FORMAT = BUSWISE_CSV_FORMAT;
"@
Set-Content -Path "$ProjectRoot\snowflake\create_stage_file_format.sql" -Value $StageFormat -Encoding UTF8

$CopyInto = @"
COPY INTO BUS_FARES
FROM @BUSWISE_STAGE/bus_fare_raw.csv
FILE_FORMAT = (FORMAT_NAME = BUSWISE_CSV_FORMAT)
ON_ERROR = 'CONTINUE';
"@
Set-Content -Path "$ProjectRoot\snowflake\copy_into_bus_fare.sql" -Value $CopyInto -Encoding UTF8

$Notebook = @'
{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# BusWise Fare Cleaning and Analysis\n",
    "Load, clean, validate, and analyse the bus fare dataset."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "import pandas as pd\n",
    "\n",
    "df = pd.read_csv('../data/raw/bus_fare_raw.csv')\n",
    "df.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "df.info()\n",
    "df.describe(include='all')"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "name": "python",
   "version": "3"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
'@
Set-Content -Path "$ProjectRoot\python\bus_fare_cleaning_analysis.ipynb" -Value $Notebook -Encoding UTF8

# Create clearly labelled placeholders for files that must later be built in their native applications.
Set-Content -Path "$ProjectRoot\excel\CREATE_buswise_excel_dashboard_here.txt" `
    -Value "Create and save buswise_excel_dashboard.xlsx in this folder." -Encoding UTF8

Set-Content -Path "$ProjectRoot\powerbi\CREATE_buswise_fare_dashboard_here.txt" `
    -Value "Create and save buswise_fare_dashboard.pbix in this folder using Power BI Desktop." -Encoding UTF8

Set-Content -Path "$ProjectRoot\tableau\CREATE_buswise_tableau_dashboard_here.txt" `
    -Value "Create and save buswise_tableau_dashboard.twbx in this folder using Tableau." -Encoding UTF8

Set-Content -Path "$ProjectRoot\images\ADD_DASHBOARD_IMAGES_HERE.txt" `
    -Value "Add excel_dashboard.png, powerbi_dashboard.png, and tableau_dashboard.png here." -Encoding UTF8

Set-Content -Path "$ProjectRoot\report\CREATE_ANALYTICS_REPORT_HERE.txt" `
    -Value "Create and save buswise_fare_analytics_report.pdf in this folder." -Encoding UTF8

if (Test-Path $DatasetSource) {
    Copy-Item $DatasetSource "$ProjectRoot\data\raw\bus_fare_raw.csv" -Force
    Copy-Item $DatasetSource "$ProjectRoot\data\processed\bus_fare_cleaned.csv" -Force
    Write-Host "Dataset copied successfully." -ForegroundColor Green
}
else {
    Write-Warning "Dataset was not found beside the setup script."
}

Write-Host ""
Write-Host "BusWise project created successfully at:" -ForegroundColor Green
Write-Host $ProjectRoot -ForegroundColor Cyan
Write-Host ""
Write-Host "Open the project folder with:" -ForegroundColor Yellow
Write-Host "explorer `"$ProjectRoot`""
